/**
 *
 * App
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 */
import React from 'react';
import Header from 'components/Header/Header';
import Slick from 'components/Slick/slick';
import Footer from 'components/Footer/Footer';
import Register from '../../components/register/Register';
import Login from '../../components/register/Login';
import Profile from '../../components/register/Profile';
import Edit from '../../components/register/editprofile';
import Filter from '../../components/product/product';
import Gallery from '../../components/gallery/gallery';
import Product from '../../components/productdetail/productDetails';
import 'bootstrap/dist/css/bootstrap.min.css';

import { BrowserRouter as Router, Route ,Switch} from 'react-router-dom'

export default function App() {
  return (
    <Router>
      <Header />
        <Switch>
          <Route path='/' exact render={props =>
          <div>
          <Slick />
          <Gallery />
          </div>
          } />
        <Route exact path="/register" component={Register} />
        <Route exact path="/login" component={Login} />
        <Route exact path="/profile" component={Profile}/>
        <Route exact path="/edit" component={Edit} />
        <Route exact path="/filter" component={Filter} />
        <Route exact path="/productdetail/:book_code" component={Product} />
      </Switch>
      <Footer />
    </Router> 
  );
}
