
import React from "react";
import { Jumbotron, Container } from "reactstrap";
import { Row, Col } from "reactstrap";
import "./footer.css";
import { Badge } from "react-bootstrap";


class footer extends React.Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return (
        <Jumbotron fluid className="jambotran">
          <Container fluid className="text-center text-md-left">
            <Row>
              <Col XS lg="1" />
              <Col XS lg="2">
                <ul className="list-unstyled">
                  <p>
                    <b>LOKI BOOKS</b>
                  </p>
                  <li>
                    <a href="#Crime">Crime</a>
                  </li>
                  <li>
                    <a href="#Modern Times">Modern Times</a>
                  </li>
                  <li>
                    <a href="#Adventure">Adventure</a>
                  </li>
                  <li>
                    <a href="#Romance">Romance</a>
                  </li>
                  <li>
                    <a href="#Suspense">Suspense</a>
                  </li>
                  <li>
                    <a href="#Comedy">Comedy</a>
                  </li>
                  <li>
                    <a href="#insider">
                    Insider<Badge variant="success">New</Badge>
                    </a>
                  </li>
                </ul>
              </Col>
              <Col XS lg="2">
                <ul className="list-unstyled">
                  <p>
                    <b>USEFUL LINKS</b>
                  </p>
                  <li>
                    <a href="#contact us">Contact Us</a>
                  </li>
                  <li>
                    <a href="#faq">FAQ</a>
                  </li>
                  <li>
                    <a href="#t&c">T & C</a>
                  </li>
                  <li>
                    <a href="#terms">Terms Of Use</a>
                  </li>
                  <li>
                    <a href="#track">Track Orders</a>
                  </li>
                  <li>
                    <a href="#shipping">Shipping</a>
                  </li>
                  <li>
                    <a href="#cancellation">Cancellation</a>
                  </li>
                  <li>
                    <a href="#returns">Returns</a>
                  </li>
                  <li>
                    <a href="#privacy">Privacy policy</a>
                  </li>
                </ul>
              </Col>
              <Col XS lg="3">
                <ul className="list-unstyled">
                  <p>
                    <b>EXPERIENCE  APP ON MOBILE</b>
                  </p>
                  <li>
                    <img
                      className="play"
                      alt="google play"
                      src="https://assets.myntassets.com/assets/images/retaillabs/2018/10/16/80cc455a-92d2-4b5c-a038-7da0d92af33f1539674178924-google_play.png"
                    />
                    <img
                      className="ios"
                      alt="ios"
                      src="https://assets.myntassets.com/assets/images/retaillabs/2018/10/16/bc5e11ad-0250-420a-ac71-115a57ca35d51539674178941-apple_store.png"
                    />
                  </li>
                  <p>
                    <b>KEEP IN TOUCH</b>
                  </p>
                  <li>
                   <a href="www.facebook.com"><img className="icon" alt="facebook" src="https://image.flaticon.com/icons/svg/216/216564.svg"/></a>
                    <img className="icon" alt="Linked in" src="https://image.flaticon.com/icons/svg/216/216570.svg" />
                    <img className="icon" alt="instagram" src="https://image.flaticon.com/icons/svg/216/216568.svg" />
                    <img className="icon" alt="Youtube" src="https://image.flaticon.com/icons/svg/216/216585.svg" />
                  </li>
                </ul>
              </Col>
              <Col XS lg="4">
                <ul className="list-unstyled">
                  <li>
                    <strong>
                      <img src="https://image.flaticon.com/icons/svg/267/267418.svg" className="icon" />
                      100% ORIGINAL
                    </strong>
                    guarantee for all products 
                  </li>
                  <br></br>
                  <li>
                    <strong>
                      <img
                        className="icon"
                        src="https://image.flaticon.com/icons/svg/267/267441.svg"
                      />
                      Return within 30days{' '}
                    </strong>
                    of receiving your order
                  </li>
                  <br></br>
                  <li>
                    <strong><img src="https://image.flaticon.com/icons/svg/267/267458.svg" className="icon"/>Get free delivery </strong>for every order above
                    Rs.1199
                  </li>
                  <br></br>
                </ul>
              </Col>
            </Row>
          </Container>
        </Jumbotron>
    );
  }
}
export default footer;
