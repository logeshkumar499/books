import React, { Component } from "react";
import { update } from './UserFunctions';
import { withRouter } from 'react-router-dom';
import jwt_decode from 'jwt-decode'

class Update extends Component {
  constructor() {
    super()
    this.state = {
      firstName: '',
      lastName: '',
      email: '',
      errors: {}
    }

    this.onChange = this.onChange.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
  }

  onChange(e) {
    this.setState({ [e.target.name]: e.target.value })
  }
  onSubmit(e) {
    e.preventDefault()

    const updateData = {
      firstName: this.state.firstName,
      lastName: this.state.lastName,
      email: this.state.email,

      token:localStorage.usertoken
    }

    update(updateData).then(res => {
        localStorage.removeItem('usertoken')
      this.props.history.push(`/login`)
    })
  }

  componentDidMount() {
    const token = localStorage.usertoken
    const decoded = jwt_decode(token)
    this.setState({
      firstName: decoded.firstName,
      lastName: decoded.lastName,
      email: decoded.email
    })
  }

  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-6 mt-5 mx-auto">
            <form noValidate onSubmit={this.onSubmit}>
              <h1 className="h3 mb-3 font-weight-normal">Edit Profile</h1>
            <div className="row">
              <div className="form-group col-6">
                <label htmlFor="name">First name</label>
                <input
                  type="text"
                  className="form-control"
                  name="firstName"
                  placeholder="Enter your first name"
                  value={this.state.firstName}
                  onChange={this.onChange}
                />
              </div>
              <div className="form-group col-6">
                <label htmlFor="name">Last name</label>
                <input
                  type="text"
                  className="form-control"
                  name="lastName"
                  placeholder="Enter your lastname name"
                  value={this.state.lastName}
                  onChange={this.onChange}
                />
              </div>
            </div>
              
              <div className="form-group">
                <label htmlFor="email">Email address</label>
                <input
                  type="email"
                  className="form-control"
                  name="email"
                  placeholder="Enter email"
                  value={this.state.email}
                  onChange={this.onChange}
                />
              </div>
              <button
                type="submit"
                className="btn btn-lg btn-primary btn-block">
                Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    )
  }
}

export default withRouter(Update)
