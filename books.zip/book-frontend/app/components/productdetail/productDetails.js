import React, { useState, useEffect } from "react";
import { Card, CardImg, Row, Col } from 'reactstrap';
import axios from 'axios';
import $ from 'jquery'
import  './productdetail.css';


 function Product(props) {
  // eslint-disable-next-line react/prop-types
  const { match: { params } } = props;
  console.log(params.book_code);

  const token=localStorage.usertoken
  const [filter,setfilter]=useState([]);
  const [id, setId] = useState({token});
  const [sizedata, setSizeData] = useState([]);

  // product details
  useEffect(() => {
    axios
      .get(`http://localhost:5000/api/productdetail/${params.book_code}`)
      .then(res => {
        console.log("product", res.data);
        setfilter(res.data)
      })
      .catch(err => {
        console.log(err)
      })
  }, [params.book_code]);

  console.log('id',id);


  function prdimg(images) {
    return images.map(data => (
      <Col lg="6" key={data}>
        <Card className="gallerycard">
          <CardImg className="galleryimg" alt="" src={data} />
        </Card>
      </Col>
    ));
  }
  return (
    <div className="container-fluid">
      {filter.map(data => (
        <div>
          <div className="row" >
            <Col xs="7">
              <Row >
                {prdimg(data.image)}
              </Row>
              <br />
            </Col>
            <Col xs='5' style={{ marginTop: "43px" }}>
            <h3  style={{ color: "#bd7183 " }}>Book Name : {data.title}</h3>
              <h4 style={{ color: "grey" }}> Author : {data.author}</h4>
              <h4 style={{ color: "grey" }}> Series : {data.series}</h4>
              <h4 style={{ display: "flex" ,color:"#145a7bd9" }}>Price :Rs.{data.price} &nbsp;&nbsp;</h4>
              <h4 style={{ color: "#368c84" }}>Published Year : {data.published_year}</h4>
              <div style={{ color: "#03a685" }}>inclusive of all taxes</div><br />
              <hr style={{ width: "99%" }} />
              <h5>BOOK DETAILS</h5>
              <div >{data.book_details}</div><br />
              <hr style={{ width: "99%" }} />
              <h6>DELIVERY OPTIONS</h6>

              <p>Tax: Applicable tax on the basis of exact location & discount will be charged at the time of checkout</p>
              <p>100% Original Products</p>
              <p>Cash on delivery might be available</p>
              <p>Author:<a href=""><b> {data.author}</b></a></p>
            </Col>
          </div>
        </div>))}
    </div>
  );
}
export default Product;

