import React, { Component } from "react";
import { Container, Card, Row, Col, Button, CardBody, CardImg}from 'reactstrap';
import "./gallery.css";
import { withRouter,Link } from 'react-router-dom';

class Gallery extends Component {
  constructor(props) {
    super(props);
    this.state = {
      product: []
    }
  }

  componentDidMount(){
      fetch('http://localhost:5000/api/gallery',{
            method:'get',
      })
      .then(res =>res.json())
      .then(product=>this.setState({product}, () => console.log('gallery fetched...', product)));
  }

  cards(){
      return this.state.product.map(data =>{
          return(
              <Col lg="3" >
                <Card className="gallerycard">
                  <Link to="/filter"><CardImg className="galleryimg" alt="gallery image" src={data.image} /></Link>
                </Card>
                <br></br>
              </Col>
              
          )
      });
  }

  render() {
    return (
      <Container fluid={true}>
      <Row>
         {this.cards()}
      </Row>
      </Container>
    );
  }
}

export default Gallery;