import React, { useState, useEffect } from "react";
import {Card,CardImg,CardText,Button,Label,Form, FormGroup,Input,Row,Col, CardFooter, Container} from 'reactstrap';
import axios from 'axios';
import { withRouter,Link } from 'react-router-dom';
import './product.css';
import $ from "jquery";

function  Filter(){
   const [filter,setfilterimage]=useState([]);
   const [user,setUser]=useState([]);
   function onChange(e){
   setUser({...user,[e.target.name]:e.target.value})
     }

      function allClear(e){
      setUser([])
       }

       $(document).ready(function(){
        $('button').on('click', function(){
            $('input[type="checkbox"]').prop('checked', false);
        });
      });
      if( user.series!='' || user.price!='' ){
            useEffect (()=>{
              axios
              .post(`http://localhost:5000/api/getproduct`,{...user})
              .then(res =>{
                console.log("1",res);
                setfilterimage(res.data);
              })
              .catch(err=>{
                console.log(err)
              })
            },[user]);
          }
          else{
            useEffect(()=>{
              axios
              .get('http://localhost:5000/api/getallproduct')
              .then(res=>{
                console.log("product",res);
                setfilterimage(res.data)
              })
              .catch(err=>{
                console.log(err)
              })
            },[]);
          }

function productimg(){
  return filter.map(data =>{
    return (
      <Col lg="3">
         <Card className="hovereffect">
           <Link to={`productdetail/${data.book_code}`} >
          <CardImg className="image" src={data.image[0]}></CardImg>
            <CardText className="title">{data.title} </CardText>
            <CardText className="author">Rs.{data.author}</CardText>
          <CardFooter className="overlay">
                <h2><Button color="success">View Book Details</Button></h2>
            </CardFooter> 
            </Link>
         </Card>
      </Col>
    )
  });
}

return(
          <Container fluid={true}>
               <h4>FILTERS</h4>
               <p>loki books Menu - <span> Items</span></p><hr/>
              <Row>
               <Col xs="2">
               <Form className="rtcol">
               <FormGroup className="CATEGORIES" check>
               <Button type="button" className="buttonsss" onClick={allClear}>Clear All</Button><br/><hr/>
                 <Label check><b>CATEGORIES</b></Label><br/>
                <Input type="checkbox" name="series" value="Crime" onChange={onChange}/>Crime<br/>
                <Input type="checkbox" name="series" value="Modern Times" onChange={onChange}/>Modern Times <br/>
                <Input type="checkbox" name="series" value="Adventure" onChange={onChange} />Adventure<br/>
                <Input type="checkbox" name="series" value="Romance"  onChange={onChange}/>Romance<br/>
                <Input type="checkbox" name="series" value="Suspense" onChange={onChange} />Suspense<br/>
                <Input type="checkbox" name="series" value="Comedy" onChange={onChange} />Comedy<br/>
             <hr/>
                <Label className="filterprice" check><b>PRICE</b></Label><br/>
                <Input type="checkbox" name="price" onChange={(e)=>{setUser({...user,price:{'$gte':301,'$lte':500}})}} />Rs.301 to Rs.500<br/>
                <Input type="checkbox" name="price" onChange={(e)=>{setUser({...user,price:{'$gte':501,'$lte':700}})}}/>Rs.501 to Rs.700<br/>
                <Input type="checkbox" name="price" onChange={(e)=>{setUser({...user,price:{'$gte':701,'$lte':999}})}}/>Rs.701 to Rs.999<br/>
              <br/>
                </FormGroup>
              </Form>
                </Col>
                <Col xs="10">
                <Row >
                {productimg()}
                <br/>
                </Row >
                </Col>
                
              </Row>
              </Container>
      );

}
  export default Filter








