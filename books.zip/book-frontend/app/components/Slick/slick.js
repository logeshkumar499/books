import React, { Component } from "react";
import Slider from "react-slick";
import { Container, Card,FlexView, CardBody, CardImg}from 'reactstrap';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";

class Slides extends Component {
  constructor() {
    super();
    this.state = {
      img: []
    };
  }

  componentDidMount(){
      fetch('http://localhost:5000/api/banner')
      .then(res =>res.json())
      .then(img =>this.setState({img}, () => console.log('images fetched...', img)));
  }
  sliders(){
      return this.state.img.map(data =>{
          return(
              <div key={data}>
                  <CardImg alt="logeshkumar123678" src={data.image} />
              </div>
          )
      });
  }
  render() {
    const settings = {
      dots: true,   
      infinite:true,        
      autoplay: true,
      speed: 1800,
      slidesToShow: 1,
      slidesToScroll: 1
    };
    return (
      <Container fluid style={{width: "98%"}}>
        <br></br>
        <Slider {...settings}>
            {this.sliders()}
        </Slider>
      <br></br>
      <br></br>
      </Container>
    );
  }
}

export default Slides;