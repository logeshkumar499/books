import React, { useState } from 'react';
import "./style.css";
import { Link } from 'react-router-dom';
import {
  Collapse, Navbar, NavbarToggler, NavbarBrand, Nav, NavItem, NavLink, UncontrolledDropdown, DropdownToggle, 
  Card, CardText, CardBody, CardTitle, Button, NavbarText
} from 'reactstrap';
// import Icon from 'react-native-vector-icons/dist/FontAwesome';


const header = (props) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggle = () => setIsOpen(!isOpen);


  return (
    <div>
      <Navbar expand="md" className="na1">
        <NavbarBrand href="/"><img src="https://i.pinimg.com/originals/a4/1e/55/a41e55923708ccb51f4fee4b271b0055.jpg" style={{ width: 60, marginTop: -7 }} /></NavbarBrand>
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar >
          <Nav className="mr-auto " navbar>
            <NavItem>
              <UncontrolledDropdown nav inNavbar>
                <DropdownToggle nav >
                  <NavLink href="#" className="link1">LOKI BOOKS</NavLink>
                  </DropdownToggle>
              </UncontrolledDropdown>
            </NavItem>
          </Nav>
          <NavbarText>
              <div className="input-group search">
                <div className="input-group-btn">
                  <img className="icon2" type="submit" src="https://image.flaticon.com/icons/svg/216/216719.svg" ></img>
                  <input type="text" className="form-control" placeholder="Search the book, series and More" name="search" />
                </div>
              </div>
            </NavbarText>
          <NavbarText className="profile" >
              <img className="icon1" src="https://image.flaticon.com/icons/svg/304/304178.svg" /><br /><span className="sp1">Profile</span>
              <div className="profileCard">
                <Card>
                  <CardBody>
                    <CardTitle>Welcome</CardTitle>
                    <CardText>To access account and manage orders</CardText><hr />
                    <Link to="/register"><Button outline color="success">SING UP</Button></Link>
                    <Link to="/login"><Button outline color="success" className="loginbtn">LOG IN </Button></Link>
                    <hr />
                    <Link to="/edit">Edit Profile</Link><br />
                    <Link to="/">Logout</Link>
                  </CardBody>
                </Card></div>
            </NavbarText>
            <NavbarText>
              <img className="icon1" src="https://image.flaticon.com/icons/svg/240/240077.svg" style={{ marginTop: 8 }} /><br /><span className="sp1">Wishlist</span>
            </NavbarText>
          <NavbarText style={{ marginRight:14}} >
                <img className="icon1" src="https://image.flaticon.com/icons/svg/211/211854.svg" style={{ marginTop: 8}} /><br /><span className="sp1">Bag</span>
          </NavbarText>
        </Collapse>
      </Navbar>
    </div>
  );
}

export default header;


