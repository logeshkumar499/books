const mongoose = require('mongoose')
const Schema = mongoose.Schema

// Create Schema
const RegisterSchema = new Schema({
  firstName: {
    type: String
  },
  lastName: {
    type: String
  },
  email: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  }
})

module.exports = register = mongoose.model('register', RegisterSchema)
