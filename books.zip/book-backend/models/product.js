const mongoose = require('mongoose')
const Schema = mongoose.Schema
// Create Schema
const ProductSchema = new Schema({
  user:{
    type:String,
    required:true
  },
  image: {
    type: Array,
    required:true
  },
  title: {
    type: String,
    required:true
  },
  author: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true
  },
  book_code: {
    type: Number,
    required: true
  },
  published_year: {
    type: String,
    required: true
  },
  series:{
    type: String,
    required:true
  },
  book_details:{
    type: String
  }
})

module.exports = product = mongoose.model('product', ProductSchema)