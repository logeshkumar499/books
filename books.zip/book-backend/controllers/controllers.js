const bcrypt = require('bcryptjs');
const banner = require('../models/banner');
const register = require('./../models/register');
const gallery = require('./../models/gallery');
const product = require('./../models/product');
const jwt = require("jsonwebtoken");

const createBanner = async function (req, res) {
  const bannerData = {
    image: req.body.image,
  }
  banner.create(bannerData)
    .then(data => {
      res.json({ message: "banner created",data })
    })
    .catch(err => {
      res.send('error:' + err)
    })
}

const getBanner = async (req, res) => {
  await banner.find()
    .then(image => { res.json(image) })
    .catch(err => { res.status(400).json('Error' + err) });
}

const updateBanner = async function (req, res) {
  banner.findById(req.params.id, function (err, data) {
    if (err) {
      return res.json(err)
    }
    if (data === null || data == null) {
      return res.json({
        status: "failed",
        message: "details not found"
      })
    }
  })
  banner.findByIdAndUpdate(req.params.id , { $set: req.body }).then(data => {
    res.json({
      message: "banner updated",data:req.body})
  }).catch(err => {
    res.json({ status: "failed", message: err.message })
  })
}

const deleteBanner = async function (req, res) {
  banner.findById(req.params.id, function (err, data) {
    if (err) {
      return res.json(err)
    }
    if (data === null || data == null) {
      return res.json({
        status: "failed",
        message: "details not found"
      })
    }
  })
  banner.findByIdAndDelete(req.params.id).then(data => {
    res.json({
      message: "item deleted",data})
  }).catch(err => {
    res.json({ status: "failed", message: err.message })
  })
}



//user registration control
const users = async (req, res) => {
  const today = new Date()
  const userData = new register({
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    email: req.body.email,
    password: req.body.password,
    created: today
  });

  register.findOne({
    email: req.body.email
  })
    .then(user => {
      if (!user) {
        bcrypt.hash(req.body.password, 10, (err, hash) => {
          userData.password = hash
          register.create(userData)
            .then(data => {
              res.json({ status: 'Registered!', data})
              console.log("register" + data);
            })
            .catch(err => {
              res.send('error: ' + err)
            })
        })
      } else {
        res.json({ error: 'User already exists' })
        console.log("User already existsr");
      }
    })
    .catch(err => {
      res.send('error: ' + err)
    })
}


//user login control 
const login = async (req, res) => {
  register.findOne({
    email: req.body.email
  })
    .then(user => {
      if (user) {
        if (bcrypt.compareSync(req.body.password, user.password)) {
          // Passwords match
          const payload = {
            _id: user._id,
            email: user.email
          }
          let token = jwt.sign(payload, process.env.SECRET_KEY, {
            expiresIn: '68h'
          })
          res.json({ message: "login successfully...", token:token })
          console.log("login success",token)
        } else {
          // Passwords don't match
          res.json({ error: 'User does not exist' })
        }
      } else {
        res.json({ error: 'User does not exist' })
      }
    })
    .catch(err => {
      res.send('error: ' + err)
    })
}

//user profile control
const profile = async (req, res) => {
  var decoded = jwt.verify(req.headers['authorization'], process.env.SECRET_KEY)

  register.findOne({
    _id: decoded._id
  })
    .then(data => {
      if (data) {
        res.json(data)
        console.log("profile success",data)
      } else {
        res.send('User does not exist')
      }
    })
    .catch(err => {
      res.send('error: ' + err)
    })
}

//user update control
const update = async (req, res) => {
  var decoded = jwt.verify(req.headers['authorization'] || req.body.token, process.env.SECRET_KEY)

  register.findOne({
    _id: decoded._id
  })
    .then(data => {
      if (data) {
        register.updateOne({ _id: decoded._id }, { $set: req.body }).then(user => {
          res.json({message:"profile updated",data:req.body})
        })
          .catch(err => {
            res.send('error: ' + err)
          })

      } else {
        res.send('User does not exist')
      }
    })
    .catch(err => {
      res.send('error: ' + err)
    })
}

//Gallery
const createGallery = async function (req, res) {
  const galleryData = new gallery({
    image: req.body.image,
  }).save()
    .then(data => {
      res.json({status:'Images stored Successfully!',image:data})
    })
    .catch(err => {
      res.send('error:' + err)
    })
}

const getGallery = async (req, res) => {
  await gallery.find()
    .then(data => { res.json(data) })
    .catch(err => { res.status(400).json('Error' + err) });
}


//product
const createProduct = async function(req,res){
  var decoded = jwt.verify(req.headers['authorization'], process.env.SECRET_KEY)

        register.findOne({
            _id: decoded._id
          })
          .then(user => {
            if (user) {
              
              const productData =new product({
                user: decoded._id,
                image: req.body.image,
                title: req.body.title,
                author: req.body.author,
                price: req.body.price,
                book_code:req.body.book_code,
                published_year: req.body.published_year,
                series: req.body.series,
                book_details: req.body.book_details
             })
              
             product.findOne({book_code: req.body.book_code})
              .then(data=>{
                if(!data){
                  
                 product.create(productData)
                 .then(stored =>{
                   res.json({
                     status:'Product Stored Successfully',
                     user:stored
                   })
                 })
                 .catch(err =>{
                   res.json({ error: err })
                  })
                }
                else{
                  res.status(500).send({
                    message:"The product is already exit"
                  })
                }
              })
              .catch(err => {
                res.send('error: ' + err)
              })
  
            } else {
              res.send('User does not exist')
            }
          })
          .catch(err => {
            res.send('error: ' + err)
          })
        }

const getproduct = async (req, res) => {
  await product.find(req.body)
    .then(data => {
      res.json(data)
    })
    .catch(err => {
      res.status(400)
        .json('Error' + err)
    });
}

const getallproduct = async (req, res) => {
  await product.find()
    .then(data => {
      res.json(data)
    })
    .catch(err => {
      res.status(400)
        .json('Error' + err)
    });
}

// All Product
const productpage = async (req, res) => {
  //console.log(req.params.id);
  await product.find({ book_code: req.params.book_code })

    .then(data => {
      res.json(data)
    })
    .catch(err => {
      res.status(400)
        .json('Error' + err)
    });
}

const updateProduct = async function (req, res) {
  product.findById(req.params._id, function (err, data) {
    if (err) {
      return res.json(err)
    }
    if (data === null || data == null) {
      return res.json({
        status: "failed",
        message: "details not found"
      })
    }
  })
  product.findByIdAndUpdate({_id: req.params._id} , { $set: req.body }).then(data => {
    res.json({
      message: "product updated",data:req.body})
  }).catch(err => {
    res.json({ status: "failed", message: err.message })
  })
}

const deleteProduct = async function (req, res) {
  product.findById(req.params._id, function (err, data) {
    if (err) {
      return res.json(err)
    }
    if (data === null || data == null) {
      return res.json({
        status: "failed",
        message: "details not found"
      })
    }
  })
  product.findByIdAndDelete({_id: req.params._id}).then(data => {
    res.json({
      message: "product deleted",data:req.body})
  }).catch(err => {
    res.json({ status: "failed", message: err.message })
  })
}

module.exports = {
  createBanner:createBanner,
  getBanner: getBanner,
  updateBanner:updateBanner,
  deleteBanner: deleteBanner,
  users: users,
  login: login,
  profile: profile,
  update: update,
  createGallery: createGallery,
  getGallery: getGallery,
  createProduct: createProduct,
  getproduct: getproduct,
  getallproduct: getallproduct,
  productpage: productpage,
  updateProduct:updateProduct,
  deleteProduct: deleteProduct,
}

