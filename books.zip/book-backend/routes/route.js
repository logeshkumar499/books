const express = require('express');
const route = express.Router();

const cors = require('cors');
const controllers = require('../controllers/controllers');

route.use(cors());  

process.env.SECRET_KEY ='secret'
//banner 
route.post('/banner',controllers.createBanner);
route.get('/banner',controllers.getBanner);
route.put('/banner/:id',controllers.updateBanner);
route.delete('/banner/:id',controllers.deleteBanner);

// user register
route.post('/register',controllers.users);
// user login
route.post('/login',controllers.login);

// user profile
route.get('/profile',controllers.profile);
route.put('/profileUpdate',controllers.update);

//gallery
route.post('/gallery',controllers.createGallery);
route.get('/gallery',controllers.getGallery);

//create product
route.post('/product',controllers.createProduct);
route.post('/getproduct',controllers.getproduct);
route.get('/getallproduct',controllers.getallproduct);
route.put('/updateProduct/:_id',controllers.updateProduct);
route.get('/productdetail/:book_code',controllers.productpage);
route.delete('/deleeProduct/:_id',controllers.deleteProduct);

module.exports = route;